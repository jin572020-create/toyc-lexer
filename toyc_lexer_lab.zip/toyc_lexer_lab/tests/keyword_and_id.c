int integer if iff
