int x;
/* bad
